//simulate loading time
setTimeout(() => {
    //hide loader and show content
    document.querySelector('.loader').style.display = 'none';
    document.querySelector('.content').style.display = 'block';
}, 15000); //seconds loading time